var classfichier_config2_d =
[
    [ "fichierConfig2D", "classfichier_config2_d.html#a4614bc2c0ab608204eaddc468337d80d", null ],
    [ "load", "classfichier_config2_d.html#a70ea01e8e45d6bd8a74415dbe7079e32", null ],
    [ "save", "classfichier_config2_d.html#ac91d6cd20fd9edc6ed71684b8d5a1b40", null ]
];