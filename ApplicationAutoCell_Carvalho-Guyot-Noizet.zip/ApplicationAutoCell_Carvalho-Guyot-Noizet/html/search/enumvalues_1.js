var searchData=
[
  ['blanc',['BLANC',['../cell_8h.html#ae60adcb558b7f2142c3aa2dd94aaa535a35653913ced93d8199f0378ec538a0c7',1,'cell.h']]]
];
