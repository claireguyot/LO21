var searchData=
[
  ['rouge',['ROUGE',['../cell_8h.html#ae60adcb558b7f2142c3aa2dd94aaa535a92b33cebaccf73541ab06eca48a31e42',1,'cell.h']]]
];
