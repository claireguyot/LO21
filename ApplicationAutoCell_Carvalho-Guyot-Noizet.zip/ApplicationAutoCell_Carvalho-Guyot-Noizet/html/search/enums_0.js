var searchData=
[
  ['dimtype',['DimType',['../sauvegarde_8h.html#ac723b01a0252e3ef0c19e62167fee796',1,'sauvegarde.h']]]
];
