var searchData=
[
  ['noir',['NOIR',['../cell_8h.html#ae60adcb558b7f2142c3aa2dd94aaa535a59e3323a198f0162330111165caaf367',1,'cell.h']]]
];
