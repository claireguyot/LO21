var searchData=
[
  ['next',['Next',['../class_cellular_automata.html#acfc9ced987c630324dcd70ceea348148',1,'CellularAutomata']]]
];
