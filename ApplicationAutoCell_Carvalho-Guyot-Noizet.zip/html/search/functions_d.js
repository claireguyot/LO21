var searchData=
[
  ['sauvegarde',['sauvegarde',['../sauvegarde_8cpp.html#a9d16542dcc8a340e36e363d5a3fa1a88',1,'sauvegarde(const CellularAutomata &amp;automate, TypeFichier t, DimType d):&#160;sauvegarde.cpp'],['../sauvegarde_8h.html#a9d16542dcc8a340e36e363d5a3fa1a88',1,'sauvegarde(const CellularAutomata &amp;automate, TypeFichier t, DimType d):&#160;sauvegarde.cpp']]],
  ['sauverautomate',['sauverAutomate',['../class_fenetre_automate.html#a72f0cef51c6dfe7be43d964552894cb1',1,'FenetreAutomate']]],
  ['sauveretat',['sauverEtat',['../class_fenetre_automate.html#aef629f1d61a3d4a776e597180bc10e59',1,'FenetreAutomate']]],
  ['save',['save',['../classfichier.html#ac54bfc9ea8c980c0b46bb291d3abdef4',1,'fichier::save()'],['../classfichier_etat1_d.html#a120ee4b6234a18bdb88c5d60bd0ef5c0',1,'fichierEtat1D::save()'],['../classfichier_etat2_d.html#a0acba6c601772898383006d2c705a177',1,'fichierEtat2D::save()'],['../classfichier_config1_d.html#a759fa0735b22b3f5cceeb0fb414fc056',1,'fichierConfig1D::save()'],['../classfichier_config2_d.html#ac91d6cd20fd9edc6ed71684b8d5a1b40',1,'fichierConfig2D::save()']]],
  ['savecontexte',['saveContexte',['../classfenetre1_d.html#a7a002ce1503501bb9c872f600a4a3986',1,'fenetre1D::saveContexte()'],['../classfenetre2_d.html#acf88b677807b775fae14cca2e424fe0c',1,'fenetre2D::saveContexte()'],['../class_sous_fenetre.html#a22836438ab9dbd8806c8fc908c5be5bc',1,'SousFenetre::saveContexte()'],['../classfenetre_config.html#a0a85954f221fb5ddcb5e1929e51a3eb5',1,'fenetreConfig::saveContexte()'],['../classfenetre_elementary_rule.html#a481768eea168b9854c439814c77591b7',1,'fenetreElementaryRule::saveContexte()'],['../classfenetre_game_of_life.html#a051a43e416ea06cf302382a099f02e94',1,'fenetreGameOfLife::saveContexte()'],['../classfenetre_feu_foret.html#a16ef18f39c2af63c42ff5a67cc882abd',1,'fenetreFeuForet::saveContexte()']]],
  ['setetat',['SetEtat',['../class_cell.html#a33dac87ec7294fdb4c67b8b430ea0946',1,'Cell']]],
  ['setetatdepart',['setEtatDepart',['../class_cellular_automata.html#a8ee6a9ee70fccd7987805e3d176fb3e1',1,'CellularAutomata']]],
  ['setrule',['setRule',['../class_cellular_automata.html#a894e9aaca0bae53d59494aab600bb11d',1,'CellularAutomata']]],
  ['setvoisinagedefinition',['setVoisinageDefinition',['../class_cellular_automata.html#aaa2d03eaa7b1b5349d67393fcad0a7fa',1,'CellularAutomata']]],
  ['sousfenetre',['SousFenetre',['../class_sous_fenetre.html#a7ba4ac9a58b9a005767f089b1f5e16bd',1,'SousFenetre']]]
];
