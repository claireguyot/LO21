var class_game_of_life =
[
    [ "GameOfLife", "class_game_of_life.html#a033f778ad4b391bbf04dfa937f7b11df", null ],
    [ "~GameOfLife", "class_game_of_life.html#a3006eb8600b82f3deff3b8efe6725569", null ],
    [ "getTransition", "class_game_of_life.html#a636421a27cb52e9f7ec161d141809919", null ],
    [ "TransitionCellule", "class_game_of_life.html#a12e6db1719e64adc023e1a7d2976d38d", null ]
];