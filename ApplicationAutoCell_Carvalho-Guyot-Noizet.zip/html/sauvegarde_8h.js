var sauvegarde_8h =
[
    [ "DimType", "sauvegarde_8h.html#ac723b01a0252e3ef0c19e62167fee796", [
      [ "_1D", "sauvegarde_8h.html#ac723b01a0252e3ef0c19e62167fee796a0fd85b1345d8b71b3b76e8101980f618", null ],
      [ "_2D", "sauvegarde_8h.html#ac723b01a0252e3ef0c19e62167fee796acff98fc949954b753f7077705091c8ee", null ]
    ] ],
    [ "TypeFichier", "sauvegarde_8h.html#af4bf09862c0294e937b809406a59c306", [
      [ "ETAT", "sauvegarde_8h.html#af4bf09862c0294e937b809406a59c306a228c7d5226de3d46b87bb264578e9c96", null ],
      [ "CONFIG", "sauvegarde_8h.html#af4bf09862c0294e937b809406a59c306a702582f7f825ca83bdb076b15b4c0fc2", null ]
    ] ],
    [ "chargement", "sauvegarde_8h.html#ad1485a8038899cd83dc86ff5d04bee3a", null ],
    [ "sauvegarde", "sauvegarde_8h.html#a9d16542dcc8a340e36e363d5a3fa1a88", null ]
];