var class_main_window =
[
    [ "MainWindow", "class_main_window.html#a996c5a2b6f77944776856f08ec30858d", null ],
    [ "closeEvent", "class_main_window.html#a05fb9d72c044aa3bb7d187b994704e2f", null ]
];