var class_automate_exception =
[
    [ "AutomateException", "class_automate_exception.html#a324660f942b04229a4795cc80c3dbe82", null ],
    [ "~AutomateException", "class_automate_exception.html#aac1e142017119bf9116fac7cdd6b0a07", null ],
    [ "what", "class_automate_exception.html#aec651fff04401e5d6eb3ee1804f1afcd", null ]
];